# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Home::Application.config.secret_token = '6e34a0f02c3c6c3c541c783dc8831b4759c7b0c0f0e93dffa652f78ebf4f0d97f81773c0a7d63e9a6a734b19333068cb2a88aef05af84c1c3a5b66ba1cee4123'
