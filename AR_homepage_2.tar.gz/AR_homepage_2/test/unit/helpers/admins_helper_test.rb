require 'test_helper'

class AdminsHelperTest < ActionView::TestCase
end
