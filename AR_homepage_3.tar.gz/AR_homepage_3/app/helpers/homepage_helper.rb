module HomepageHelper
end
