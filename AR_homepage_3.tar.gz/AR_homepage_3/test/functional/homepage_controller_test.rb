require 'test_helper'

class HomepageControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
