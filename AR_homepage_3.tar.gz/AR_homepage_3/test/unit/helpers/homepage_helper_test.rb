require 'test_helper'

class HomepageHelperTest < ActionView::TestCase
end
